function toggleMenu() {
  const navLinks = document.querySelector(".header1 nav");
  const buttons = document.querySelector(".header2");

  if (navLinks.classList.contains("show")) {
    navLinks.classList.remove("show");
    navLinks.classList.add("hide");
  } else {
    navLinks.classList.remove("hide");
    navLinks.classList.add("show");
  }

  if (buttons.classList.contains("show")) {
    buttons.classList.remove("show");
    buttons.classList.add("hide");
  } else {
    buttons.classList.remove("hide");
    buttons.classList.add("show");
  }
}
